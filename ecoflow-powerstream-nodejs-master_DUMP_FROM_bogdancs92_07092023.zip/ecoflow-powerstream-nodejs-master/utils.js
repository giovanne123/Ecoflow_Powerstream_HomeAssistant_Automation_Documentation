function log(msg) {
  console.log(msg);
}
module.exports = {
  log
};